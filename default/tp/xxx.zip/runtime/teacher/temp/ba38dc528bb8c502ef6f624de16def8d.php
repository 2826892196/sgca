<?php /*a:1:{s:66:"/usr/share/nginx/html/tp/app/teacher/view/index/teachers_list.html";i:1653116793;}*/ ?>
<!DOCTYPE html>
<html>
<meta name="referrer" content="no-referrer">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">

<link rel="stylesheet" href="/static/css/base.css" type="text/css">

<style>
    .teacher {
        margin: 3.6% 2.3% 4.7% 4.1%;
        display: flex;
        flex-wrap: wrap;
    }
    
    .teacher_item {
        width: 48%;
        margin-right: 1.8%;
        margin-bottom: 1.8%;
        position: relative;
        background: #F7F7F7;
    }
    
    .avatar {
        width: 50%;
        padding-left: 2.5%;
        float: right;
    }
    
    .teacher_title {
        font-family: SourceHanSansCN-Medium;
        font-size: 14px;
        color: #656565;
        margin-top: 2.2%;
        margin-left: 1.9%;
    }
    
    .teacher_name {
        font-family: SourceHanSansCN-Bold;
        font-size: 1.875rem;
        color: #1B44DB;
        margin-left: 1.9%;
    }
    
    .teacher_detail {
        width: 50%;
        font-family: SourceHanSansCN-Normal;
        font-size: 14px;
        color: #656565;
        margin-left: 1.9%;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 6;
        overflow: hidden;
    }
    
    .more_btn {
        position: absolute;
        bottom: 1.6%;
        left: 1.9%;
        width: 40px;
        height: 40px;
    }
    
    @media only screen and (max-width: 1170px) {
        .teacher_detail {
            -webkit-line-clamp: 5;
        }
        .more_btn {
            width: 2.187rem;
            height: 2.187rem;
        }
    }
    
    @media only screen and (max-width: 1040px) {
        .teacher_detail {
            -webkit-line-clamp: 4;
        }
        .more_btn {
            width: 1.875rem;
            height: 1.875rem;
        }
    }
    
    @media only screen and (max-width: 944px) {
        .teacher_detail {
            -webkit-line-clamp: 3;
        }
        .more_btn {
            width: 1.562rem;
            height: 1.562rem;
        }
    }
    
    @media only screen and (max-width: 768px) {
        .teacher_item {
            width: 100%;
        }
        .teacher_title {
            font-size: 12px;
        }
        .teacher_name {
            font-size: 28px;
        }
        .teacher_detail {
            font-size: 12px;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 6;
            overflow: hidden;
        }
        .more_btn {
            width: 1.25rem;
            height: 1.25rem;
        }
    }
    
    @media only screen and (max-width: 50.937rem) {
        .teacher_detail {
            -webkit-line-clamp: 5;
        }
    }
    
    @media only screen and (max-width: 450px) {
        .teacher_title {
            font-size: 11px;
        }
        .teacher_name {
            font-size: 27px;
        }
        .teacher_detail {
            font-size: 11px;
            -webkit-line-clamp: 4;
        }
    }
    
    @media only screen and (max-width: 410px) {
        .teacher_title {
            font-size: 10px;
        }
        .teacher_name {
            font-size: 26px;
        }
        .teacher_detail {
            font-size: 10px;
            -webkit-line-clamp: 3;
        }
    }
</style>

<body>
    <div class="nav">
        <div class="nav_detail">
            <img src="/static/Image/dark_logo.png">
            <div class="m_nav">
                <button class="btn-nav">
                  <span class="icon-bar top"></span>
                  <span class="icon-bar middle"></span>
                  <span class="icon-bar bottom"></span>
                </button>
            </div>

            <div class="nav-content hideNav hidden">
                <ul class="nav-list">
                    <li class="nav-item" style="">
                        <span class="item_skin">首页</span>
                    </li>
                    <li class="nav-item">
                        <span class="item_skin">学院介绍</span>
                    </li>
                    <li class="nav-item">
                        <span class="item_skin">培训课程</span>
                    </li>
                    <li class="nav-item">
                        <span class="item_skin">讲师介绍</span>
                    </li>
                    <!-- <li class="nav-item">
                        <span class="item_skin">校区介绍</span>
                    </li> -->
                    <li class="nav-item">
                        <span class="item_skin">活动资讯</span>
                    </li>
                </ul>
            </div>
        </div>
        <p class="nav_title">讲师介绍</p>
    </div>
    <div class="base_detail">

        <div class="teacher">
            <?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): if( count($data)==0 ) : echo "" ;else: foreach($data as $key=>$value): ?>
            <div class="teacher_item">

                <a href="<?php echo url('/teacher/detail/'.$value['id']); ?>">
                    <img class="avatar" src="<?php echo htmlentities($value['teacher_avatar']); ?>" alt="">
                    <p class="teacher_title">讲师介绍</p>
                    <p class="teacher_name"><?php echo htmlentities($value['teacher_name']); ?></p>
                    <p class="teacher_detail"><?php echo htmlentities($value['Introduction']); ?></p>
                    <img class="more_btn" src="/static/Image/teacher_more.png" alt="">
                </a>

            </div>
            <?php endforeach; endif; else: echo "" ;endif; ?>

        </div>
    </div>
    <div class="bottom">
        <img style="width: 100%;" src="/static/Image/bottom_bg.png" alt="">
        <div>
            <img class="bottom_logo" src="/static/Image/light_logo.png" alt=" ">
            <img class="bottom_redbook" src="/static/Image/redbook.png" alt="">
            <img class="bottom_wechat" src="/static/Image/wechat.png" alt="">
        </div>

        <div class="bottom_detail">
            <div class="bottom_detail_left">
                <p class="bottom_phone">联系电话：1111111</p>

                <p class="bottom_address">北京校区：xxxxxxx</p>
                <p class="bottom_address">北京校区：xxxxxxx</p>
            </div>
            <ul class="bottom_ul">
                <li><a href="<?php echo url('/course/list'); ?>">培训课程</a></li>
                <li><a href="<?php echo url('/introduced'); ?>">学院介绍</a></li>
                <li><a href="<?php echo url('/teacher/list'); ?>">讲师介绍</a></li>
                <li><a href="<?php echo url('/address/list'); ?>">校区介绍</a></li>
                <li><a href="<?php echo url('/activity/list/1'); ?>">活动资讯</a></li>
            </ul>
        </div>
        <div class="bottom_line"></div>
        <p class="copyright">Copyright © 2022-2023 寻品咖啡学院 All Rights Reserved. 版权备案号：京ICP备2022018085号</p>
    </div>


</body>
<script src="/static/js/jquery-2.1.1.min.js"></script>
<script>
    $(window).load(function() {
        $('.btn-nav').on('click tap', function() {
            $('.nav-content').toggleClass('showNav hideNav').removeClass('hidden');
            $(this).toggleClass('animated');
        });
    });
    $(".item_skin").bind('click', function(index) {
        $('.btn-nav').click();
        var index = $(".item_skin").index($(this));
        setTimeout(() => {
            switch (index) {
                case 0:
                    window.location.href = "<?php echo url('/home'); ?>";
                    break;

                case 1:
                    window.location.href = "<?php echo url('/introduced'); ?>";
                    break;

                case 2:
                    window.location.href = "<?php echo url('/course/list'); ?>";
                    break;

                case 3:
                    window.location.href = "<?php echo url('/teacher/list'); ?>";
                    break;
                case 4:
                    window.location.href = "<?php echo url('/address/list'); ?>";
                    break;

                case 5:
                    window.location.href = "<?php echo url('/activity/list/1'); ?>";
                    break;

                default:
                    break;
            }
        }, 500);
    })
</script>

</html>