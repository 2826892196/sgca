<?php /*a:1:{s:67:"/usr/share/nginx/html/tp/app/teacher/view/index/teacher_detail.html";i:1652095236;}*/ ?>
<!DOCTYPE html>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="stylesheet" href="/static/css/base.css" type="text/css">

<style>
    .teacher_container {
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
        margin: 3.6% 2.3% 2.9% 2.3%;
    }
    
    .teacher_introduce {
        margin: 5% 4.8% 6.25% 4.8%;
    }
    
    .teacher_title {
        font-family: SourceHanSansCN-Bold;
        font-size: 1.6vw;
        color: #303030;
        letter-spacing: 0.22px;
        text-align: justify;
        line-height: 2.8vw;
        font-weight: 700;
    }
    
    .teacher_avatar {
        float: right;
        width: 40%;
        overflow: hidden;
    }
    
    .teacher_name {
        font-family: SourceHanSansCN-Bold;
        font-size: 3.0.9rem;
        color: #303030;
        letter-spacing: 0.42px;
        line-height: 1.6vw;
        font-weight: 700;
        margin-top: 1.3%;
        margin-bottom: 3.1%;
    }
    
    .teacher_introduce ul {
        width: 50%;
    }
    
    .teacher_introduce li {
        font-family: SourceHanSansCN-Regular;
        font-size: 1.3vw;
        color: #474747;
        letter-spacing: 0.18px;
        text-align: justify;
        line-height: 4vw;
        font-weight: 400;
    }
    
    .teacher_introduce li span {
        font-family: SourceHanSansCN-Bold;
        font-size: 1.4vw;
        color: #474747;
        text-align: justify;
    }
    
    .teacher_detail {
        margin: 0 4.8% 5.5% 4.8%;
    }
    
    .line {
        width: 100%;
        border: .5px solid #DDDDDD;
        margin-top: 1.3%;
        margin-bottom: 1.9%;
    }
    
    .content {
        word-wrap: break-word;
        word-break: break-all;
    }
    
    .content img {
        width: 70%;
        margin-left: auto;
        margin-right: auto;
        display: block;
    }
    
    .teacher_course {
        margin: 0 4.8% 5.5% 4.8%;
    }
    
    .teacher_detail div {
        font-family: SourceHanSansCN-Normal;
        font-size: 1.5vw;
        color: #474747;
        letter-spacing: 0.22px;
        text-align: justify;
        line-height: 2.5vw;
        font-weight: 400;
    }
    
    .teacher_detail_div {
        border: 0.8% solid #00000000;
        font-family: SourceHanSansCN-Normal;
        font-size: 1.6vw;
        color: #303030;
        letter-spacing: 0.23px;
        text-align: center;
        line-height: 2.5vw;
        font-weight: 400;
        margin-bottom: 5%;
    }
    
    .teacher_detail_div img {
        margin-bottom: 5%;
        width: 100%;
    }
    
    @media only screen and (max-width: 768px) {
        .teacher_introduce li span {
            font-size: 4vw;
        }
        .teacher_title {
            font-size: 4.4vw;
            line-height: 8vw;
        }
        .teacher_name {
            font-size: 10vw;
            line-height: 10.959rem;
        }
        .teacher_introduce li {
            font-size: 4vw;
            line-height: 6vw;
            margin-bottom: 10%;
        }
        .teacher_detail {
            font-size: 4.4vw;
            line-height: 8vw;
        }
        .teacher_detail div {
            font-family: SourceHanSansCN-Normal;
            font-size: 4vw;
            color: #474747;
            letter-spacing: 0.22px;
            text-align: justify;
            line-height: 5vw;
            font-weight: 400;
        }
        .teacher_detail_div {
            border: 0.8% solid #00000000;
            font-family: SourceHanSansCN-Normal;
            font-size: 3.0.959rem;
            color: #303030;
            letter-spacing: 0.23px;
            text-align: center;
            line-height: 5vw;
            font-weight: 400;
        }
    }
</style>

<body>
    <div class="nav">
        <div class="nav_detail">
            <img src="/static/Image/dark_logo.png">
            <div class="m_nav">
                <button class="btn-nav">
                  <span class="icon-bar top"></span>
                  <span class="icon-bar middle"></span>
                  <span class="icon-bar bottom"></span>
                </button>
            </div>

            <div class="nav-content hideNav hidden">
                <ul class="nav-list">
                    <li class="nav-item" style="">
                        <span class="item_skin">首页</span>
                    </li>
                    <li class="nav-item">
                        <span class="item_skin">学院介绍</span>
                    </li>
                    <li class="nav-item">
                        <span class="item_skin">培训课程</span>
                    </li>
                    <li class="nav-item">
                        <span class="item_skin">讲师介绍</span>
                    </li>
                    <!-- <li class="nav-item">
                        <span class="item_skin">校区介绍</span>
                    </li> -->
                    <li class="nav-item">
                        <span class="item_skin">活动资讯</span>
                    </li>
                </ul>
            </div>
        </div>
        <p class="nav_title">讲师介绍</p>
    </div>
    <div class="teacher">
        <div class="teacher_introduce">
            <p class="teacher_title">讲师介绍</p>
            <div style="width: 100%;overflow: hidden;">
                <img class="teacher_avatar" src="<?php echo htmlentities($teacher_data['avatar']); ?>" alt="">
                <p class="teacher_name"><?php echo htmlentities($teacher_data['name']); ?></p>
                <?php echo htmlspecialchars_decode($teacher_data['title']); ?>
            </div>
        </div>
        <div class="teacher_detail">
            <p class="teacher_title">详情介绍</p>
            <div class="line"></div>
            <div class="content">
                <?php echo htmlspecialchars_decode($teacher_data['detail']); ?>
            </div>
        </div>
        <div class="teacher_course">
            <p class="teacher_title">相关课程</p>
            <div class="line"></div>
            <div class="teacher_container">
                <?php if(is_array($course_data) || $course_data instanceof \think\Collection || $course_data instanceof \think\Paginator): if( count($course_data)==0 ) : echo "" ;else: foreach($course_data as $key=>$value): ?>
                <a href="<?php echo url('/course/detail/'.$value['id']); ?>">
                    <div class="teacher_detail_div">
                        <img src="/static/Image/course_bg_<?php echo htmlentities($value['id']); ?>.png">
                        <p><?php echo htmlentities($value['title']); ?></p>
                    </div>
                </a>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
        </div>
    </div>
    <div class="bottom">
        <img style="width: 100%;" src="/static/Image/bottom_bg.png" alt="">
        <div>
            <img class="bottom_logo" src="/static/Image/dark_logo.png " alt=" ">
            <img class="bottom_redbook" src="/static/Image/redbook.png" alt="">
            <img class="bottom_wechat" src="/static/Image/wechat.png" alt="">
        </div>

        <div>
            <p class="bottom_phone">联系电话：1111111</p>
            <ul class="bottom_ul">
                <li><a href="<?php echo url('/course/list'); ?>">培训课程</a></li>
                <li><a href="<?php echo url('/introduced'); ?>">学院介绍</a></li>
                <li><a href="<?php echo url('/teacher/list'); ?>">讲师介绍</a></li>
                <li><a href="<?php echo url('/address/list'); ?>">校区介绍</a></li>
                <li><a href="<?php echo url('/activity/list/1'); ?>">活动资讯</a></li>
            </ul>
            <p class="bottom_address">北京校区：xxxxxxx</p>
            <p class="bottom_address">北京校区：xxxxxxx</p>

            <div class="bottom_line"></div>
            <p class="copyright">Copyright © 2022-2023 寻品咖啡学院 All Rights Reserved. 版权备案号：京ICP备2022018085号</p>

        </div>
    </div>


</body>
<script src="/static/js/jquery-2.1.1.min.js"></script>
<script>
    $(window).load(function() {
        $('.btn-nav').on('click tap', function() {
            $('.nav-content').toggleClass('showNav hideNav').removeClass('hidden');
            $(this).toggleClass('animated');
        });
    });
    $(".item_skin").bind('click', function(index) {
        $('.btn-nav').click();

        var index = $(".item_skin").index($(this));
        setTimeout(() => {
            switch (index) {
                case 0:
                    window.location.href = "<?php echo url('/home'); ?>";
                    break;

                case 1:
                    window.location.href = "<?php echo url('/introduced'); ?>";
                    break;

                case 2:
                    window.location.href = "<?php echo url('/course/list'); ?>";
                    break;

                case 3:
                    window.location.href = "<?php echo url('/teacher/list'); ?>";
                    break;
                case 4:
                    window.location.href = "<?php echo url('/address/list'); ?>";
                    break;

                case 5:
                    window.location.href = "<?php echo url('/activity/list/1'); ?>";
                    break;

                default:
                    break;
            }
        }, 500);
    })
</script>

</html>