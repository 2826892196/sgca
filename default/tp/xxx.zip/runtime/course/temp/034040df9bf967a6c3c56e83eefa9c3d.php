<?php /*a:1:{s:65:"/usr/share/nginx/html/tp/app/course/view/index/course_detail.html";i:1652156096;}*/ ?>
<!DOCTYPE html>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="stylesheet" href="/static/css/base.css" type="text/css">
<style>
    .nav_title {
        font-family: SourceHanSansCN-Heavy;
        font-size: 2.5vw;
        color: #FFFFFF;
        text-align: center;
        margin-top: 4%;
    }
    
    .nav_course_title {
        text-align: center;
        font-family: SourceHanSansCN-Heavy;
        font-size: 5vw;
        color: #FFFFFF;
        margin: 0;
    }
    
    .nav_course_day {
        font-family: SourceHanSansCN-Heavy;
        font-size: 2.3vw;
        color: #FFFFFF;
        text-align: center;
    }
    
    .big_box {
        margin: 1.9em;
        border: 1px solid #979797;
        border-radius: 1.9em;
        overflow: hidden;
    }
    
    .course_title {
        background: #efefef;
        border-bottom: 1px solid #979797;
        padding: 1.9em 3.8em;
    }
    
    .e_title {
        font-family: SourceHanSansCN-Bold;
        font-size: 2.6rem;
        color: #303030;
    }
    
    .c_title {
        font-family: SourceHanSansCN-Bold;
        font-size: 2.8rem;
        color: #1B44DB;
    }
    
    .learning_object_detail {
        padding: 1.9em;
        display: flex;
        gap: 3.1em;
    }
    
    .learning_object_detail_item {
        display: flex;
    }
    
    .learning_object_detail_item img {
        width: 4.7em;
        height: 4.7em;
    }
    
    .learning_object_detail_item p {
        font-family: SourceHanSansCN-Normal;
        font-size: 1.6rem;
        color: #303030;
        margin-left: 1.5em;
    }
    
    .course_objectives_basics {
        display: flex;
        padding: 4.4em 1.8em 0;
        flex-wrap: wrap;
        gap: 2%;
    }
    
    .basics_item {
        width: 23.5%;
        margin-bottom: 4.4em;
        position: relative;
    }
    
    .basics_item_title {
        position: absolute;
        top: -0.6em;
        padding: .1em 1.3em;
        background: #231916;
        color: white;
        border-radius: 1.4em;
        font-family: SourceHanSansCN-Bold;
        font-size: 1.4rem;
        color: #FFFFFF;
    }
    
    .basics_item_detail {
        padding: 1.5em;
        background: #F7F7F7;
        border-radius: 1.3em;
        font-family: SourceHanSansCN-Normal;
        font-size: 1.6rem;
        color: #474747;
    }
    
    .course_objectives_advanced {
        display: flex;
        padding: 0em 1.8em 0;
        flex-wrap: wrap;
        gap: 2%;
    }
    
    .advanced_item {
        width: 23.5%;
        margin-bottom: 4.4em;
        position: relative;
    }
    
    .advanced_item_title {
        position: absolute;
        top: -0.6em;
        padding: .1em 1.3em;
        background: #1B43DB;
        color: white;
        border-radius: 1.4em;
        font-family: SourceHanSansCN-Bold;
        font-size: 1.4rem;
        color: #FFFFFF;
    }
    
    .advanced_item_detail {
        padding: 1.5em;
        background: #F7F7F7;
        border-radius: 1.3em;
        font-family: SourceHanSansCN-Normal;
        font-size: 1.6rem;
        color: #474747;
    }
    
    h1 {
        margin: 2em;
        font-family: SourceHanSansCN-Normal;
        font-size: 1.6rem;
        color: #474747;
    }
    
    .certificate_detail {
        display: flex;
        justify-content: space-evenly;
        margin: 0 4em 4em;
    }
    
    .certificate_detail_item {
        text-align: center;
    }
    
    .certificate_detail_item p {
        margin-bottom: 3em;
        font-family: SourceHanSansCN-Normal;
        font-size: 1.3rem;
    }
    
    .welfare_detail {
        margin-top: 1em;
        display: flex;
        justify-content: space-evenly;
    }
    
    .welfare_detail_item {
        text-align: center;
    }
    
    .welfare_detail_item p {
        margin: 1.3em 0 2.5em;
        font-family: SourceHanSansCN-Normal;
        font-size: 1.6rem;
        color: #474747;
    }
    
    .welfare_detail_item img {
        width: 5.25em;
        height: 5.25em;
    }
    
    .outline_item {
        padding: 2.8em;
    }
    
    .outline_item table {
        border: 1px solid #AFAFAF;
        width: 100%
    }
    
    .outline_item table tr {
        border: 1px solid #AFAFAF;
        text-align: center;
    }
    
    .outline_item_day {
        border: 1px solid #AFAFAF;
        width: 30%;
        padding: 1em 0;
        font-family: SourceHanSansCN-Bold;
        font-size: 1.6rem;
        color: #303030;
    }
    
    .outline_item_detail {
        border: 1px solid #AFAFAF;
        width: 70%;
        padding: 1em 0;
        font-family: SourceHanSansCN-Normal;
        font-size: 1.6rem;
        color: #474747;
    }
    
    .about_instructor_detail {
        padding: 6em 8em 5em 4em;
    }
    
    .about_instructor_detail img {
        width: 50%;
        float: right;
	margin-bottom: 5%;
    }
    
    .teacher_name {
        font-family: SourceHanSansCN-Bold;
        font-size: 3.1rem;
        color: #303030;
        margin-bottom: 1.1em;
    }
    
    .about_instructor_detail_item li {
        font-family: SourceHanSansCN-Regular;
        font-size: 1.4rem;
        color: #474747;
        margin-bottom: 1em;
    }
    
    .about_instructor_detail_item li span {
        font-family: SourceHanSansCN-Bold;
        font-size: 1.4rem;
        color: #474747;
    }
    
    .teacher_line {
        width: 90%;
        height: 1px;
        margin: 2% 5%;
        background: #DDDDDD;
    }
    
    .course_price {
        background: url(/static/Image/course_price_bg.png) no-repeat center center;
        background-size: cover;
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-family: SourceHanSansCN-Bold;
        font-size: 2.5vw;
        color: #FFFFFF;
        padding: 1.1% 2.2%;
    }
    
    @media only screen and (max-width: 768px) {
        .big_box {
            margin: 0.95em;
            border-radius: 0.95em;
        }
        .course_title {
            padding: 0.95em 1.9em;
        }
        .e_title {
            font-size: 1.3rem;
        }
        .c_title {
            font-size: 1.4rem;
        }
        .learning_object_detail {
            padding: 0.95em;
            gap: 1.55em;
            flex-wrap: wrap;
        }
        .learning_object_detail_item {
            width: 100%;
        }
        .learning_object_detail_item img {
            width: 2.35em;
            height: 2.35em;
        }
        .learning_object_detail_item p {
            font-size: 0.8rem;
            margin-left: 0.75em;
        }
        .course_objectives_basics {
            padding: 2.2em 0.9em 0;
        }
        .basics_item {
            width: 100%;
            margin-bottom: 2.2em;
        }
        .basics_item_title {
            top: -1em;
            padding: .05em 0.65em;
            border-radius: 0.7em;
            font-size: 0.7rem;
        }
        .basics_item_detail {
            padding: 1em;
            border-radius: 0.65em;
            font-size: 0.8rem;
        }
        .course_objectives_advanced {
            padding: 0em 0.9em 0;
        }
        .advanced_item {
            width: 100%;
            margin-bottom: 2.2em;
        }
        .advanced_item_title {
            top: -1em;
            padding: .05em 0.65em;
            border-radius: 0.7em;
            font-size: 0.7rem;
        }
        .advanced_item_detail {
            padding: 0.75em;
            border-radius: 0.65em;
            font-size: 0.8rem;
        }
        h1 {
            margin: 1em;
            font-size: 0.8rem;
        }
        .certificate_detail {
            flex-wrap: wrap;
            margin: 0 2em 2em;
        }
        .certificate_detail_item {
            width: 100%;
            margin-bottom: 1em;
        }
        .certificate_detail_item p {
            margin-bottom: 1.5em;
            font-size: 0.65rem;
        }
        .certificate_detail_item img {
            width: 80%;
        }
        .welfare_detail {
            flex-wrap: wrap;
        }
        .welfare_detail_item {
            width: 100%;
        }
        .welfare_detail_item p {
            margin: 0.65em 0 1.25em;
            font-size: 0.8rem;
        }
        .welfare_detail_item img {
            width: 2.625em;
            height: 2.625em;
        }
        .outline_item {
            padding: 1.4em;
        }
        .outline_item_day {
            padding: 0.5em 0;
            font-size: 0.8rem;
        }
        .outline_item_detail {
            padding: 0.5em 1em;
            font-size: 0.8rem;
        }
        .about_instructor_detail {
            padding: 3em 4em 2.5em 2em;
        }
        .about_instructor_detail img {
            float: none;
        }
        .teacher_name {
            font-size: 1.55rem;
            margin-bottom: 0.55em;
        }
        .about_instructor_detail_item li {
            font-size: 0.7rem;
            margin-bottom: 0.5em;
        }
        .about_instructor_detail_item li span {
            font-size: 0.7rem;
        }
        .course_price {
            background: url(/static/Image/course_price_bg.png) no-repeat center center;
            background-size: cover;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-family: SourceHanSansCN-Bold;
            font-size: 3vw;
            color: #FFFFFF;
            padding: 1.1% 2.2%;
        }
    }
</style>

<body>
    <div class="nav">
        <div class="nav_detail">
            <img src="/static/Image/dark_logo.png">
            <div class="m_nav">
                <button class="btn-nav">
                  <span class="icon-bar top"></span>
                  <span class="icon-bar middle"></span>
                  <span class="icon-bar bottom"></span>
                </button>
            </div>

            <div class="nav-content hideNav hidden">
                <ul class="nav-list">
                    <li class="nav-item" style="">
                        <span class="item_skin">首页</span>
                    </li>
                    <li class="nav-item">
                        <span class="item_skin">学院介绍</span>
                    </li>
                    <li class="nav-item">
                        <span class="item_skin">培训课程</span>
                    </li>
                    <li class="nav-item">
                        <span class="item_skin">讲师介绍</span>
                    </li>
                    <!-- <li class="nav-item">
                        <span class="item_skin">校区介绍</span>
                    </li> -->
                    <li class="nav-item">
                        <span class="item_skin">活动资讯</span>
                    </li>
                </ul>
            </div>
        </div>
        <p class="nav_title">学院介绍</p>
        <p class="nav_course_title"><?php echo htmlentities($data['title']); ?></p>
        <p class="nav_course_day">(全日制)</p>
    </div>
    <div class="course_price">
        <p>课程人数 <?php echo htmlentities($data['num']); ?>人</p>
        <p>学费 ￥<?php echo htmlentities($data['price']); ?>（<?php echo htmlentities($data['days']); ?>天）</p>
    </div>
    <div class="big_box">
        <div class="course_title">
            <p class="e_title">Learning</p>
            <p class="e_title">object</p>
            <p class="c_title">学习对象 ★</p>
        </div>
        <div class="learning_object_detail">
            <?php echo htmlspecialchars_decode($data['learning_object']); ?>
        </div>
    </div>
    <div class="big_box">
        <div class="course_title">
            <p class="e_title">Course</p>
            <p class="e_title">objectives</p>
            <p class="c_title">课程目标 ★</p>
        </div>
        <div>
            <?php echo htmlspecialchars_decode($data['course_objectives']); ?>
        </div>
    </div>
    <div class="big_box" style="display: flex;">
        <div style="width: 50%;">
            <div class="course_title" style="border-bottom: 1px solid #979797;">
                <p class="e_title">Learning</p>
                <p class="e_title">form</p>
                <p class="c_title">学习形式 ★</p>
            </div>
            <div>
                <h1><?php echo htmlentities($data['learning_form']); ?></h1>
            </div>
        </div>
        <div style="width: 50%;border-left: 1px solid #979797;">
            <div class="course_title" style="border-bottom: 1px solid #979797;">
                <p class="e_title">Learning</p>
                <p class="e_title">cycle</p>
                <p class="c_title">学习周期 ★</p>
            </div>
            <div>
                <h1><?php echo htmlentities($data['learning_cycle']); ?></h1>
            </div>
        </div>
    </div>
    <div class="big_box ">
        <div class="course_title">
            <p class="e_title">Tuition</p>
            <p class="e_title">includes</p>
            <p class="c_title">学费包含 ★</p>
        </div>
        <div>
            <h1>
                <?php echo htmlspecialchars_decode($data['tuition_includes']); ?>
            </h1>
        </div>
    </div>
    <?php if($data['about_certificates'] != ''): ?>
    <div class="big_box ">
        <div class="course_title">
            <p class="e_title">About</p>
            <p class="e_title">Certificates</p>
            <p class="c_title">关于证书 ★</p>
        </div>
        <div>
            <?php echo htmlspecialchars_decode($data['about_certificates']); ?>
        </div>
    </div><?php endif; ?>
    <div class="big_box">
        <div class="course_title">
            <p class="e_title">Syllabus</p>
            <p class="c_title">课程大纲 ★</p>
        </div>
        <div class="outline_item">
            <?php echo htmlspecialchars_decode($data['syllabus']); ?>
        </div>
    </div>
    <div class="big_box">
        <div class="course_title">
            <p class="e_title">Course</p>
            <p class="e_title">benefits</p>
            <p class="c_title">课程福利 ★</p>
        </div>
        <div>
            <?php echo htmlspecialchars_decode($data['course_benefits']); ?>
        </div>
    </div>
    <div class="big_box">
        <div class="course_title">
            <p class="e_title">About</p>
            <p class="e_title">Instructor</p>
            <p class="c_title">讲师介绍 ★</p>
        </div>
        <?php if(is_array($teacher_data) || $teacher_data instanceof \think\Collection || $teacher_data instanceof \think\Paginator): $k = 0; $__LIST__ = $teacher_data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$value): $mod = ($k % 2 );++$k;if($k != '1'): ?>
        <div class="teacher_line"></div>
        <?php endif; ?>
        <div class="about_instructor_detail">
            <img src="<?php echo htmlentities($value['teacher_avatar']); ?>" alt="">
            <div class="about_instructor_detail_item">
                <p class="teacher_name"><?php echo htmlentities($value['teacher_name']); ?></p>
                <?php echo htmlspecialchars_decode($value['teacher_title']); ?>
            </div>
        </div>
	<div style="clear: both;"></div>
        <?php endforeach; endif; else: echo "" ;endif; ?>

    </div>
    <div class="bottom">
        <img style="width: 100%;" src="/static/Image/bottom_bg.png" alt="">
        <div>
            <img class="bottom_logo" src="/static/Image/dark_logo.png " alt=" ">
            <img class="bottom_redbook" src="/static/Image/redbook.png" alt="">
            <img class="bottom_wechat" src="/static/Image/wechat.png" alt="">
        </div>

        <div>
            <p class="bottom_phone">联系电话：1111111</p>
            <ul class="bottom_ul">
                <li><a href="<?php echo url('/course/list'); ?>">培训课程</a></li>
                <li><a href="<?php echo url('/introduced'); ?>">学院介绍</a></li>
                <li><a href="<?php echo url('/teacher/list'); ?>">讲师介绍</a></li>
                <li><a href="<?php echo url('/address/list'); ?>">校区介绍</a></li>
                <li><a href="<?php echo url('/activity/list/1'); ?>">活动资讯</a></li>
            </ul>
            <p class="bottom_address">北京校区：xxxxxxx</p>
            <p class="bottom_address">北京校区：xxxxxxx</p>

            <div class="bottom_line"></div>
            <p class="copyright">Copyright © 2022-2023 寻品咖啡学院 All Rights Reserved. 版权备案号：京ICP备2022018085号</p>

        </div>
    </div>


</body>

<script src="/static/js/jquery-2.1.1.min.js"></script>
<script>
    $(window).load(function() {
        $('.btn-nav').on('click tap', function() {
            $('.nav-content').toggleClass('showNav hideNav').removeClass('hidden');
            $(this).toggleClass('animated');
        });
    });
    $(".item_skin").bind('click', function(index) {
        $('.btn-nav').click();

        var index = $(".item_skin").index($(this));
        setTimeout(() => {
            switch (index) {
                case 0:
                    window.location.href = "<?php echo url('/home'); ?>";
                    break;

                case 1:
                    window.location.href = "<?php echo url('/introduced'); ?>";
                    break;

                case 2:
                    window.location.href = "<?php echo url('/course/list'); ?>";
                    break;

                case 3:
                    window.location.href = "<?php echo url('/teacher/list'); ?>";
                    break;
                case 4:
                    window.location.href = "<?php echo url('/address/list'); ?>";
                    break;

                case 5:
                    window.location.href = "<?php echo url('/activity/list/1'); ?>";
                    break;

                default:
                    break;
            }
        }, 500);
    })
</script>

</html>
