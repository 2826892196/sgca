<?php /*a:1:{s:63:"/usr/share/nginx/html/tp/app/course/view/index/course_list.html";i:1652691439;}*/ ?>
<!DOCTYPE html>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="stylesheet" href="/static/css/base.css" type="text/css">

<style>
    .course_time {
        margin: -2% 2%;
    }
    
    h1 {
        margin-top: 4%;
        padding-bottom: 2%;
        font-family: SourceHanSansCN-Bold;
        font-size: 2.0.959rem;
        color: #303030;
    }
    
    .course_container {
        margin: 1.5% 3.3% 3.7% 3.3%;
        display: grid;
        grid-gap: 2.5%;
        grid-template-columns: 31.6% 31.6% 31.6%;
        grid-template-rows: auto;
        grid-auto-flow: row dense;
    }
    
    .course_item {
        padding-right: 1.6%;
        font-family: SourceHanSansCN-Normal;
        font-size: 1.8vw;
        color: #303030;
        letter-spacing: 0.23px;
        text-align: center;
        line-height: 2.3vw;
        font-weight: 400;
    }
    
    .course_item img {
        margin-bottom: 0.6%;
        width: 50%;
    }
    
    .time_title {
        font-family: SourceHanSansCN-Medium;
        font-size: 1.4vw;
        color: #303030;
        padding: 1% 2%;
        background: rgb(247, 247, 247);
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-radius: 1.25rem;
    }
    
    .time_detail_dark {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: rgb(247, 247, 247);
        min-height: 170px;
        padding: 2%;
        border-radius: 1.25rem;
    }
    
    .time_detail_dark img,
    .time_detail img {
        width: 70%;
    }
    
    .time_detail {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: white;
        min-height: 170px;
        padding: 2%;
    }
    
    .time_detail_title {
        font-family: SourceHanSansCN-Bold;
        font-size: 0.959rem;
        color: #3B65FF;
    }
    
    .time_detail_price {
        font-family: SourceHanSansCN-Bold;
        font-size: 0.959rem;
        color: #303030;
    }
    
    .time_detail_days {
        font-family: SourceHanSansCN-Normal;
        font-size: 1.3vw;
        color: #303030;
    }
    
    @media only screen and (max-width: 768px) {
        h1 {
            margin-top: 4%;
            padding-bottom: 2%;
            font-family: SourceHanSansCN-Bold;
            font-size: 4.4vw;
            color: #303030;
        }
        .time_title {
            font-size: 2.8vw;
        }
        .time_detail_title {
            font-size: 3.5vw;
        }
        .time_detail_price {
            font-size: 3.5vw;
        }
        .time_detail_days {
            font-size: 3vw;
        }
        .course_item {
            font-size: 3.6vw;
            line-height: 5vw;
        }
    }
</style>

<body>
    <div class="nav">
        <div class="nav_detail">
            <img src="/static/Image/dark_logo.png">
            <div class="m_nav">
                <button class="btn-nav">
                  <span class="icon-bar top"></span>
                  <span class="icon-bar middle"></span>
                  <span class="icon-bar bottom"></span>
                </button>
            </div>

            <div class="nav-content hideNav hidden">
                <ul class="nav-list">
                    <li class="nav-item" style="">
                        <span class="item_skin">首页</span>
                    </li>
                    <li class="nav-item">
                        <span class="item_skin">学院介绍</span>
                    </li>
                    <li class="nav-item">
                        <span class="item_skin">培训课程</span>
                    </li>
                    <li class="nav-item">
                        <span class="item_skin">讲师介绍</span>
                    </li>
                    <!-- <li class="nav-item">
                        <span class="item_skin">校区介绍</span>
                    </li> -->
                    <li class="nav-item">
                        <span class="item_skin">活动资讯</span>
                    </li>
                </ul>
            </div>
        </div>
        <p class="nav_title">学院介绍</p>
    </div>
    <div class="course_time">
        <h1>2022年排课计划</h1>
        <ul>
            <li class="time_title">
                <p>课程名称&费用</p>
                <p>时间&地点</p>
            </li>
            <?php if(is_array($time) || $time instanceof \think\Collection || $time instanceof \think\Paginator): $k = 0; $__LIST__ = $time;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$value): $mod = ($k % 2 );++$k;if($k%2 == 0): ?>
            <li class="time_detail_dark"><?php else: ?>
                <li class="time_detail"><?php endif; ?>

                    <img src="/static/Image/course_time_<?php echo htmlentities($value['id']); ?>.png" alt="">
                    <div style="text-align: right;">
                        <p class="time_detail_title"><?php echo htmlentities($value['title']); ?></p>
                        <span class="time_detail_price"><?php echo htmlentities($value['price']); ?></span><span class="time_detail_days"> / <?php echo htmlentities($value['days']); ?>天</span>
                    </div>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
        <h1>寻品技能课程</h1>
        <div class="course_container">
            <?php if(is_array($skills) || $skills instanceof \think\Collection || $skills instanceof \think\Paginator): if( count($skills)==0 ) : echo "" ;else: foreach($skills as $key=>$value): ?>
            <a href="<?php echo url('/course/detail/'.$value['id']); ?>">
                <div class="course_item">
                    <img style="width: 100%;" src="/static/Image/course_bg_<?php echo htmlentities($value['id']); ?>.png">
                    <p><?php echo htmlentities($value['title']); ?></p>
                </div>
            </a>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </div>
        <h1>寻品商业课程</h1>
        <div class="course_container">
            <?php if(is_array($business) || $business instanceof \think\Collection || $business instanceof \think\Paginator): if( count($business)==0 ) : echo "" ;else: foreach($business as $key=>$value): ?>
            <a href="<?php echo url('/course/detail/'.$value['id']); ?>">
                <div class="course_item">
                    <img style="width: 100%;" src="/static/Image/course_bg_<?php echo htmlentities($value['id']); ?>.png">
                    <p><?php echo htmlentities($value['title']); ?></p>
                </div>
            </a>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </div>
    </div>
    <div class="bottom">
        <img style="width: 100%;" src="/static/Image/bottom_bg.png" alt="">
        <div>
            <img class="bottom_logo" src="/static/Image/dark_logo.png " alt=" ">
            <img class="bottom_redbook" src="/static/Image/redbook.png" alt="">
            <img class="bottom_wechat" src="/static/Image/wechat.png" alt="">
        </div>

        <div>
            <p class="bottom_phone">联系电话：1111111</p>
            <ul class="bottom_ul">
                <li><a href="<?php echo url('/course/list'); ?>">培训课程</a></li>
                <li><a href="<?php echo url('/introduced'); ?>">学院介绍</a></li>
                <li><a href="<?php echo url('/teacher/list'); ?>">讲师介绍</a></li>
                <li><a href="<?php echo url('/address/list'); ?>">校区介绍</a></li>
                <li><a href="<?php echo url('/activity/list/1'); ?>">活动资讯</a></li>
            </ul>
            <p class="bottom_address">北京校区：xxxxxxx</p>
            <p class="bottom_address">北京校区：xxxxxxx</p>

            <div class="bottom_line"></div>
            <p class="copyright">Copyright © 2022-2023 寻品咖啡学院 All Rights Reserved. 版权备案号：京ICP备2022018085号</p>

        </div>
    </div>


</body>
<script src="/static/js/jquery-2.1.1.min.js"></script>
<script>
    $(window).load(function() {
        $('.btn-nav').on('click tap', function() {
            $('.nav-content').toggleClass('showNav hideNav').removeClass('hidden');
            $(this).toggleClass('animated');
        });
    });
    $(".item_skin").bind('click', function(index) {
        $('.btn-nav').click();

        var index = $(".item_skin").index($(this));
        setTimeout(() => {
            switch (index) {
                case 0:
                    window.location.href = "<?php echo url('/home'); ?>";
                    break;

                case 1:
                    window.location.href = "<?php echo url('/introduced'); ?>";
                    break;

                case 2:
                    window.location.href = "<?php echo url('/course/list'); ?>";
                    break;

                case 3:
                    window.location.href = "<?php echo url('/teacher/list'); ?>";
                    break;
                case 4:
                    window.location.href = "<?php echo url('/address/list'); ?>";
                    break;

                case 5:
                    window.location.href = "<?php echo url('/activity/list/1'); ?>";
                    break;

                default:
                    break;
            }
        }, 500);
    })
</script>

</html>