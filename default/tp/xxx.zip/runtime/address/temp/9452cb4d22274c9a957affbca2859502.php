<?php /*a:1:{s:67:"/usr/share/nginx/html/tp/app/address/view/index/address_detail.html";i:1652095236;}*/ ?>
<!DOCTYPE html>
<html>
<meta name="referrer" content="no-referrer">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">

<link rel="stylesheet" href="/static/css/base.css" type="text/css">

<style>
    .address {
        margin: 5% 7.5% 5.5% 7.5%;
    }
    
    .address img {
        width: 70%;
        margin-left: auto;
        margin-right: auto;
        display: block;
    }
    
    h1 {
        font-family: SourceHanSansCN-Bold;
        font-size: 3.5vw;
        color: #303030;
        /* letter-spacing: 0.33px; */
        margin-bottom: 5%;
    }
    
    h2 {
        font-family: SourceHanSansCN-Bold;
        font-size: 2.5vw;
        color: #303030;
        letter-spacing: 0.23px;
        /* line-height: 52px; */
        margin-bottom: 2%;
    }
    
    h3 {
        font-family: SourceHanSansCN-Normal;
        font-size: 2.0.959rem;
        color: #474747;
        letter-spacing: 0.22px;
        text-align: justify;
        line-height: 5vw;
    }
    
    img {
        margin-bottom: 5%;
    }
    
    @media only screen and (max-width: 768px) {
        h1 {
            font-size: 6vw;
        }
        h2 {
            font-size: 4vw;
        }
        h3 {
            font-size: 3vw;
        }
    }
</style>

<body>
    <div class="nav">
        <div class="nav_detail">
            <img src="/static/Image/dark_logo.png">
            <div class="m_nav">
                <button class="btn-nav">
                  <span class="icon-bar top"></span>
                  <span class="icon-bar middle"></span>
                  <span class="icon-bar bottom"></span>
                </button>
            </div>

            <div class="nav-content hideNav hidden">
                <ul class="nav-list">
                    <li class="nav-item" style="">
                        <span class="item_skin">首页</span>
                    </li>
                    <li class="nav-item">
                        <span class="item_skin">学院介绍</span>
                    </li>
                    <li class="nav-item">
                        <span class="item_skin">培训课程</span>
                    </li>
                    <li class="nav-item">
                        <span class="item_skin">讲师介绍</span>
                    </li>
                    <!-- <li class="nav-item">
                        <span class="item_skin">校区介绍</span>
                    </li> -->
                    <li class="nav-item">
                        <span class="item_skin">活动资讯</span>
                    </li>
                </ul>
            </div>
        </div>
        <p class="nav_title">最新资讯</p>
    </div>
    <div class="address">
        <h1><?php echo htmlentities($address_detail['name']); ?></h1>
        <h2>地址：<?php echo htmlentities($address_detail['address']); ?></h2>
        <h2>电话：<?php echo htmlentities($address_detail['phone']); ?></h2>
        <h2>邮编：<?php echo htmlentities($address_detail['zip_code']); ?></h2>
        <img src="<?php echo htmlentities($address_detail['address_img']); ?>" alt="">
        <h2>校区介绍</h2>
        <h3><?php echo htmlspecialchars_decode($address_detail['detail']); ?></h3>
    </div>
    <div class="bottom">
        <img style="width: 100%;" src="/static/Image/bottom_bg.png" alt="">
        <div>
            <img class="bottom_logo" src="/static/Image/dark_logo.png " alt=" ">
            <img class="bottom_redbook" src="/static/Image/redbook.png" alt="">
            <img class="bottom_wechat" src="/static/Image/wechat.png" alt="">
        </div>

        <div>
            <p class="bottom_phone">联系电话：1111111</p>
            <ul class="bottom_ul">
                <li><a href="<?php echo url('/course/list'); ?>">培训课程</a></li>
                <li><a href="<?php echo url('/introduced'); ?>">学院介绍</a></li>
                <li><a href="<?php echo url('/teacher/list'); ?>">讲师介绍</a></li>
                <li><a href="<?php echo url('/address/list'); ?>">校区介绍</a></li>
                <li><a href="<?php echo url('/activity/list/1'); ?>">活动资讯</a></li>
            </ul>
            <p class="bottom_address">北京校区：xxxxxxx</p>
            <p class="bottom_address">北京校区：xxxxxxx</p>

            <div class="bottom_line"></div>
            <p class="copyright">Copyright © 2022-2023 寻品咖啡学院 All Rights Reserved. 版权备案号：京ICP备2022018085号</p>

        </div>
    </div>


</body>
<script src="/static/js/jquery-2.1.1.min.js"></script>
<script>
    $(window).load(function() {
        $('.btn-nav').on('click tap', function() {
            $('.nav-content').toggleClass('showNav hideNav').removeClass('hidden');
            $(this).toggleClass('animated');
        });
    });
    $(".item_skin").bind('click', function(index) {
        $('.btn-nav').click();

        var index = $(".item_skin").index($(this));
        setTimeout(() => {
            switch (index) {
                case 0:
                    window.location.href = "<?php echo url('/home'); ?>";
                    break;

                case 1:
                    window.location.href = "<?php echo url('/introduced'); ?>";
                    break;

                case 2:
                    window.location.href = "<?php echo url('/course/list'); ?>";
                    break;

                case 3:
                    window.location.href = "<?php echo url('/teacher/list'); ?>";
                    break;
                case 4:
                    window.location.href = "<?php echo url('/address/list'); ?>";
                    break;

                case 5:
                    window.location.href = "<?php echo url('/activity/list/1'); ?>";
                    break;

                default:
                    break;
            }
        }, 500);
    })
</script>

</html>