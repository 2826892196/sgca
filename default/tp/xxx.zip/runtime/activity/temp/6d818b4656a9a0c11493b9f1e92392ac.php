<?php /*a:1:{s:67:"/usr/share/nginx/html/tp/app/activity/view/index/activity_list.html";i:1653116793;}*/ ?>
<!DOCTYPE html>
<html>
<meta name="referrer" content="no-referrer">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">

<link rel="stylesheet" href="/static/css/base.css" type="text/css">
<style>
    .new_activity {
        background: #1B44DB;
        margin: 3.8% 4.5% 3.3%;
        width: 91%;
        overflow: hidden;
    }
    
    .new_activity_img {
        float: right;
        width: 40%;
        margin-left: 4.9%;
    }
    
    .new_activity_time {
        font-family: SourceHanSansCN-Normal;
        font-size: 18px;
        color: #FFFFFF;
        font-weight: 400;
        margin-top: 1.25rem;
        margin-left: 2.9%;
    }
    
    .new_activity_title {
        font-family: SourceHanSansCN-Medium;
        font-size: 1.875rem;
        color: #FFFFFF;
        font-weight: 500;
        margin-left: 2.9%;
        margin-top: 9px;
    }
    
    .new_activity_detail {
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 5;
        overflow: hidden;
        font-family: SourceHanSansCN-Normal;
        font-size: 14px;
        color: #FFFFFF;
        /* font-weight: 400; */
        margin-left: 2.9%;
        margin-top: 16px;
        margin-bottom: 2%;
    }
    
    .activity_nav {
        margin: 0 7.6%;
    }
    
    .activity_nav ul {
        display: flex;
        flex-flow: row wrap;
    }
    
    .activity_nav ul li {
        font-family: SourceHanSansCN-Medium;
        font-size: 16px;
        color: #121519;
        font-weight: 500;
        border: 1px solid #979797;
        border-radius: 22px;
        margin-right: 1%;
        margin-bottom: 1%;
        padding: 0 19px;
    }
    
    .selected {
        font-family: SourceHanSansCN-Medium;
        font-size: 16px;
        background: #0b0b0b;
        font-weight: 500;
        border-radius: 22px;
        margin-right: 1%;
        margin-bottom: 1%;
        padding: 0 19px;
    }
    
    .selected a {
        color: white;
    }
    
    .activity_img {
        width: 25%;
    }
    
    .activity_line {
        width: 84.8%;
        height: 1px;
        margin: 1.9% 7.6%;
        background: #DDDDDD;
    }
    
    .activity {
        display: flex;
        margin: 0 7.6%;
        margin-bottom: 1.9%;
    }
    
    .activity_time {
        width: 15.5%;
    }
    
    .activity_time_child {
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        background: #F1F5F8;
        border-radius: 0.937rem;
        padding: 1%;
    }
    
    .activity_time_month {
        font-family: SourceHanSansCN-Medium;
        font-size: 1.875rem;
        color: #656565;
        font-weight: 500;
    }
    
    .activity_time_year {
        font-family: SourceHanSansCN-Medium;
        font-size: 26px;
        color: #656565;
        font-weight: 500;
    }
    
    .activity_detail {
        width: 55.5%;
        margin-left: 2.5%;
        margin-top: 0.3%;
        margin-right: 2%;
    }
    
    .activity_detail_title {
        font-family: SourceHanSansCN-Medium;
        font-size: 18px;
        color: #1B44DB;
        font-weight: 500;
        margin-bottom: 1%;
    }
    
    .activity_detail_detail {
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 4;
        overflow: hidden;
        font-family: SourceHanSansCN-Normal;
        font-size: 14px;
        color: #1B44DB;
        font-weight: 400;
    }
    
    @media only screen and (max-width: 1090px) {
        .activity_detail_detail {
            -webkit-line-clamp: 4;
        }
    }
    
    @media only screen and (max-width: 91.25rem) {
        .activity_detail_detail {
            -webkit-line-clamp: 3;
        }
        .activity_time_month {
            font-size: 26px;
        }
        .activity_time_year {
            font-size: 22px;
        }
    }
    
    @media only screen and (max-width: 111.25rem) {
        .new_activity_detail {
            -webkit-line-clamp: 4;
        }
    }
    
    @media only screen and (max-width: 990px) {
        .new_activity_detail {
            -webkit-line-clamp: 3;
        }
    }
    
    @media only screen and (max-width: 900px) {
        .new_activity_time {
            font-size: 14px;
        }
        .new_activity_title {
            font-size: 26px;
        }
        .new_activity_detail {
            -webkit-line-clamp: 3;
            font-size: 10px;
        }
    }
    
    @media only screen and (max-width: 768px) {
        .new_activity_img {
            float: none;
            width: 100%;
            margin-left: 0;
        }
        .new_activity_time {
            font-size: 14px;
            margin-top: 10px;
        }
        .new_activity_title {
            font-size: 1.25rem;
            margin-top: 0px;
        }
        .new_activity_detail {
            -webkit-line-clamp: 3;
            font-size: 10px;
            margin: 0px 10px 10px;
        }
        .activity_nav ul li {
            font-size: 10px;
        }
        .selected {
            font-size: 10px;
        }
        .activity_time {
            width: 20%;
        }
        .activity_time_child {
            border-radius: 5px;
            padding: 1%;
        }
        .activity_time_month {
            font-size: 14px;
        }
        .activity_time_year {
            font-size: 12px;
        }
        .activity_detail_title {
            font-size: 12px;
        }
        .activity_detail_detail {
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
            font-size: 10px;
        }
        .activity_img {
            width: 30%;
        }
    }
</style>

<body>
    <div class="nav">
        <div class="nav_detail">
            <img src="/static/Image/dark_logo.png">
            <div class="m_nav">
                <button class="btn-nav">
                  <span class="icon-bar top"></span>
                  <span class="icon-bar middle"></span>
                  <span class="icon-bar bottom"></span>
                </button>
            </div>

            <div class="nav-content hideNav hidden">
                <ul class="nav-list">
                    <li class="nav-item" style="">
                        <span class="item_skin">首页</span>
                    </li>
                    <li class="nav-item">
                        <span class="item_skin">学院介绍</span>
                    </li>
                    <li class="nav-item">
                        <span class="item_skin">培训课程</span>
                    </li>
                    <li class="nav-item">
                        <span class="item_skin">讲师介绍</span>
                    </li>
                    <!-- <li class="nav-item">
                        <span class="item_skin">校区介绍</span>
                    </li> -->
                    <li class="nav-item">
                        <span class="item_skin">活动资讯</span>
                    </li>
                </ul>
            </div>
        </div>
        <p class="nav_title">最新资讯</p>
    </div>
    <div class="base_detail">


        <div class="new_activity">
            <a href="<?php echo url('/activity/detail/'.$new_activity['id']); ?>">
                <img class="new_activity_img" src="<?php echo htmlentities($new_activity['img']); ?>" alt="">
                <p class="new_activity_time"><?php echo htmlentities($new_activity['time']); ?></p>
                <p class="new_activity_title"><?php echo htmlentities($new_activity['title']); ?></p>
                <p class="new_activity_detail"><?php echo htmlentities($new_activity['introduction']); ?></p>
                <div style="clear: both;"></div>
            </a>
        </div>


        <div class="activity_nav">
            <ul>
                <?php if(is_array($topic) || $topic instanceof \think\Collection || $topic instanceof \think\Paginator): $k = 0; $__LIST__ = $topic;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$value): $mod = ($k % 2 );++$k;if($k == $topic_id): ?>
                <li class="selected"><a href="<?php echo url('/activity/list/'.$value['id']); ?>"><?php echo htmlentities($value['name']); ?></a></li>
                <?php else: ?>
                <li><a class="" href="<?php echo url('/activity/list/'.$value['id']); ?>"><?php echo htmlentities($value['name']); ?></a></li>
                <?php endif; ?> <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </div>

        <?php if(is_array($activity_list) || $activity_list instanceof \think\Collection || $activity_list instanceof \think\Paginator): if( count($activity_list)==0 ) : echo "" ;else: foreach($activity_list as $key=>$value): ?>
        <div class="activity_line"></div>
        <div class="activity">
            <div class="activity_time">
                <div class="activity_time_child">
                    <p class="activity_time_month"><?php echo htmlentities($value['month']); ?></p>
                    <p class="activity_time_year"><?php echo htmlentities($value['year']); ?></p>
                </div>

            </div>

            <div class="activity_detail">
                <a href="<?php echo url('/activity/detail/'.$value['id']); ?>">
                    <p class="activity_detail_title"><?php echo htmlentities($value['title']); ?></p>
                    <p class="activity_detail_detail"><?php echo htmlentities($value['introduction']); ?></p>
                </a>

            </div>
            <img class="activity_img" src="<?php echo htmlentities($value['img']); ?>" alt="">

        </div>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>

    <div class="bottom">
        <img style="width: 100%;" src="/static/Image/bottom_bg.png" alt="">
        <div>
            <img class="bottom_logo" src="/static/Image/light_logo.png" alt=" ">
            <img class="bottom_redbook" src="/static/Image/redbook.png" alt="">
            <img class="bottom_wechat" src="/static/Image/wechat.png" alt="">
        </div>

        <div class="bottom_detail">
            <div class="bottom_detail_left">
                <p class="bottom_phone">联系电话：1111111</p>

                <p class="bottom_address">北京校区：xxxxxxx</p>
                <p class="bottom_address">北京校区：xxxxxxx</p>
            </div>
            <ul class="bottom_ul">
                <li><a href="<?php echo url('/course/list'); ?>">培训课程</a></li>
                <li><a href="<?php echo url('/introduced'); ?>">学院介绍</a></li>
                <li><a href="<?php echo url('/teacher/list'); ?>">讲师介绍</a></li>
                <li><a href="<?php echo url('/address/list'); ?>">校区介绍</a></li>
                <li><a href="<?php echo url('/activity/list/1'); ?>">活动资讯</a></li>
            </ul>
        </div>
        <div class="bottom_line"></div>
        <p class="copyright">Copyright © 2022-2023 寻品咖啡学院 All Rights Reserved. 版权备案号：京ICP备2022018085号</p>
    </div>


</body>
<script src="/static/js/jquery-2.1.1.min.js"></script>
<script>
    $(window).load(function() {
        $('.btn-nav').on('click tap', function() {
            $('.nav-content').toggleClass('showNav hideNav').removeClass('hidden');
            $(this).toggleClass('animated');
        });
    });
    $(".item_skin").bind('click', function(index) {
        $('.btn-nav').click();

        var index = $(".item_skin").index($(this));
        setTimeout(() => {
            switch (index) {
                case 0:
                    window.location.href = "<?php echo url('/home'); ?>";
                    break;

                case 1:
                    window.location.href = "<?php echo url('/introduced'); ?>";
                    break;

                case 2:
                    window.location.href = "<?php echo url('/course/list'); ?>";
                    break;

                case 3:
                    window.location.href = "<?php echo url('/teacher/list'); ?>";
                    break;
                case 4:
                    window.location.href = "<?php echo url('/address/list'); ?>";
                    break;

                case 5:
                    window.location.href = "<?php echo url('/activity/list/1'); ?>";
                    break;

                default:
                    break;
            }
        }, 500);
    })
</script>

</html>