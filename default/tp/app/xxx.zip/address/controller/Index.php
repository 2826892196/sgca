<?php
namespace app\address\controller;
use app\BaseController;

use think\facade\Db;

class Index extends BaseController {
    public function list()
    {
        $address_list = db::table('address')->select();
        return view("address_list", ["address_list" => $address_list]);
    }

    public function detail($id)
    {
        $address_detail = db::table('address')->where('id', $id)->find();
        return view("address_detail", ["address_detail" => $address_detail]);
    }
}
?>